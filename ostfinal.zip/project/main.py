from google.appengine.ext.webapp.util import run_wsgi_app
from survey import app

run_wsgi_app(app)
